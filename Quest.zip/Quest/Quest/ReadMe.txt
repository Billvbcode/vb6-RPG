Adventure Game

Map Tiles Buttons:
Minimap      - turns minimap on or off
New World    - Creates a blank world
Make map     - Swithes between Make Map and Play game
Item Tiles   - Swithes between World tiles and Item Tiles
Visible      - Swithes between visible and invisible items

World Map Buttons:
Save         - Save the world or saves the game
Load         - Loads the world or loads a game
All Items    - Displays visible and invisible items(Only for map making)
Items        - Displays only visible items 

******To start a game:******
1) On Map Tiles board - Push the Play Game button
2) On World Mapboard  - Enter the world name (A1 or M1 or W1)
3) On World Mapboard  - Push the Load button 

Every time a map is loaded the quests will alternate between quest 1 and quest 2.

******To making a game:***** 
There are World tiles and items tiles
The world tiles are 
  1) Walkable  (0-47)  (16=where to start on the first board)
  2) Doors      (48-95)
  2) Not walkable  (95-207)

The Item tiles are either items, people or money

How the game works.
Pick a world name(suggestion use A1 through Z1)
Create a world and add all the world tiles first.
then you can add doors then visible item tiles and
finally add the invisible tiles.

During the set up you can right mouse click on a door or person or ? or drum to
change what that square does

How door tiles work:
The door tile can do any of three things
  1)  be a store (all the item sell for one price)
       to create a store click on the items tiles and place them in the store
       then click on a coin item to determine the price
  2) lead to another world
      Enter the name of the new world in the text field and then push the world button
  3) be an end of game
     Enter why the game ends in the text field and then push the evil button

How Item tiles work:
The item tiles can either be visible or invisible
If you add a lock then player will require a key to of the same color
If you add a person - that person will send you on a quest for 1 - 4 objects
once you get those objects the person will give you money and item 5
If you add a ? then you must find the object requested before you can pass.
If you add a drum then you could just add item 5 and that item would be given to the player. 
The ? or drum will disappear once quest has been done.
You can also have the person or ? or drum be an end of game.

There can be one or two quest possible for
  1) Door (as stores or to lead to new worlds)
    (A store will sell the top items in quest 1 and
      the bottom items in quest 2)
    (A door will lead world 1 in quest 1 and
     world 2 in quest 2)
  2) People
   (A person will ask for the top items in quest 1 and
     the bottom items in quest 2)

The second quest is optional.

Every time a map is loaded the quests will alternate between quest 1 
and quest 2 (only if two quest exist).

Everytime you push the Load button, the map will alternate between
quest 1 and quest two

Do not add two quest to ? or barrels as these items dissapear once a quest
has been finished.
 
The game plays the same in the map making and the play mode,
except that you can display all the invisible tiles at the push of 
the ALL Items button. If you want to remove items from a world, have the 
player pick up the tile then save the world, and the tile will no longer be on the board.
You can put walkable tile so you the can move by the ? tile then replace them
with no walkable tile when the game is finished.

You can not have a square do two different actions so you can not put
the ? on top of a door. 

You can not move onto a no walk square to  pick up an item

You can not pick up people or locks or the ?

How to make the game more difficult:
There is a not walkable world tile drum that look like the item drum 
so you can hide a the wakable item drum amoung some non-walkable drums

You can add more end games items

You could have the return from a world be in a different spot then the enter world

You could enter a world a not be able to leave without a quest item

You could require the same quest item to get into several rooms, but one room
will give you the item you need to win the game.

 